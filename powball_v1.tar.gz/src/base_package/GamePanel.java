package base_package;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class GamePanel extends JPanel {

	protected Paddle mypaddle;
	//protected int level;
	protected Timer timer;
	protected Ball myball;
	protected Brick bricks[];
	protected boolean ingame;
	private String message = new String();
	
	public GamePanel(int level) {
		//this.level = level;
		initGame();
		
		this.setSize(Main.windowX, Main.windowY);
		this.setBackground(Color.white);
		this.setLayout(null);
		this.setVisible(true);
		
		this.setFocusable(true);
		this.setDoubleBuffered(true);
		this.addKeyListener(this.mypaddle);
		
		this.timer = new Timer();
		this.timer.scheduleAtFixedRate(new ScheduleTask(), 1000, 10);
	}
	
	private void initGame() {
		this.mypaddle = new Paddle();
		this.myball = new Ball();
		this.bricks = new Brick[24];
		this.ingame = true;
		int k = 0;
		for (int i=0;i<8;i++)
		{
			for (int j=0;j<3;j++)
			{
				bricks[k] = new Brick(i*125, j*30);
				k++;
			}
		}
	}
	
	class ScheduleTask extends TimerTask {

		@Override
		public void run() {
			myball.move();
			mypaddle.move();
			collosionDetect();

			repaint();
		}
		
	}
	
	public void collosionDetect() {
		//ha a labda alul kimegy, vége a játéknak vereséggel
		if (myball.getRect().getMaxY()>=getHeight())
		{
			stopGame();
			this.message = "Vesztettél!";
		}
		//ha az összes tégla le lett rombolva, vége a játéknak győzelemmel
		boolean allDestroyed = true;
		for (Brick b : bricks)
		{
			if (!b.isDestroyed())
			{
				allDestroyed = false;
			}
		}
		if (allDestroyed)
		{
			stopGame();
			this.message = "Győztél!";
		}
		//labda és ütő
		if (myball.getRect().intersects(mypaddle.getRect()))
		{
			//legegyszerűbb eset, simán csak visszapattan
			if (myball.getRect().getMaxY()>=mypaddle.getY())
			{
				myball.setDy(-1);
			}
			//a többi eset implenentálásra szorul!
		}
		//labda és téglák
		for (Brick b : bricks)
		{
			if (!b.isDestroyed() && b.getRect().intersects(myball.getRect()))
			{
				//sima visszapattanás
				if (myball.getRect().getY()<=b.getRect().getMaxY())
				{
					myball.setDy(1);
					b.setDestroyed(true);
				}
			}
		}
	}
	
	private void stopGame() {
		this.ingame = false;
		this.timer.cancel();
	}

	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paint(java.awt.Graphics)
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		if (ingame)
		{
			//clear the background (white)
			g.setColor(Color.white);
			g.fillRect(0, 0, getWidth(), getHeight());
			//paint the ball
			g.drawImage(myball.getImage(), myball.getX(), myball.getY(), myball.getWidth(), myball.getHeight(), this);
			//paint the paddle
			g.drawImage(mypaddle.getImage(), mypaddle.getX(), mypaddle.getY(), mypaddle.getWidth(), mypaddle.getHeight(), this);
			//paint the bricks
			for (Brick b : bricks) {
				if (!b.isDestroyed())
				{
					g.drawImage(b.getImage(), b.getX(), b.getY(), b.getWidth(), b.getHeight(), this);
				}
			}
		}
		else
		{
			g.setColor(Color.black);
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
			g.drawString(this.message, getWidth()/2-50, getHeight()/2);
		}
		
		Toolkit.getDefaultToolkit().sync();
		g.dispose();
	}
}
