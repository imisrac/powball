/**
 * 
 */
package base_package;

import javax.swing.JFrame;


/**
 * @author imisrac
 *
 */
public class Main {

	protected static JFrame mainFrame;
	protected static int windowX = 1000, windowY = 600;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int level = 1;
		
		mainFrame = new JFrame("Fireball!");
		mainFrame.setLayout(null);
		mainFrame.setSize(windowX+3, windowY+32);
		mainFrame.setResizable(false);
		mainFrame.setVisible(true);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		GamePanel gamePanel = new GamePanel(level);
		mainFrame.add(gamePanel);
		
		}

}
