/**
 * 
 */
package base_package;

import javax.swing.ImageIcon;


/**
 * @author imisrac
 *
 */
public class Ball extends Sprite {

	protected int dx;
	protected int dy;
	 
    // Private constructor prevents instantiation from other classes
    public Ball() {
    	this.image = new ImageIcon("ball.png").getImage();
    	this.width = this.image.getWidth(null);
    	this.height = this.image.getHeight(null);
    	
    	resetState();
    }
    
    /**
	 * @param dx the dx to set
	 */
	public void setDx(int dx) {
		this.dx = dx;
	}

	/**
	 * @param dy the dy to set
	 */
	public void setDy(int dy) {
		this.dy = dy;
	}

	private void resetState() {
		this.x = 200;
		this.y = 200;
		this.dx = 1;
		this.dy = -1;
	}
    
    public void move() {
		this.x += this.dx;
		this.y += this.dy;
		
		if (x<=0)
		{
			dx=1;
		}
		if (x+width>=Main.windowX)
		{
			dx=-1;
		}
		if (y<=0)
		{
			dy=1;
		}
	}

}
